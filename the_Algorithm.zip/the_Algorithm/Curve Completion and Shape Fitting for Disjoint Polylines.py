ytufrom split_disjoint import split_polylines_to_disjoint, extend_and_connect_polylines, points_are_close
from helper import read_csv, plot
from detect_shapes import fit_shape, calculate_polygon_error, fit_line
import numpy as np
import math

def finalize_curves(polylines):
    completed_shapes = []
    polylines.sort(key=lambda x: len(x), reverse=True)

    for i, polyline in enumerate(polylines):
        if completed_shapes:
            matched = False
            for j, existing_shape in enumerate(completed_shapes):
                if existing_shape[3] == 'line':
                    slope, intercept = existing_shape[4][0]
                    avg_distance = np.mean(np.abs(polyline[:, 1] - slope * polyline[:, 0] - intercept))
                    if avg_distance < 10:
                        start1, end1 = polyline[0], polyline[-1]
                        start2, end2 = existing_shape[1][0], existing_shape[1][-1]

                        dists = [np.linalg.norm(start1 - start2), np.linalg.norm(start1 - end2),
                                 np.linalg.norm(end1 - start2), np.linalg.norm(end1 - end2)]
                        min_dist_idx = np.argmin(dists)

                        if min_dist_idx == 0:
                            combined_points = np.concatenate((polyline[::-1], existing_shape[1]), axis=0)
                        elif min_dist_idx == 1:
                            combined_points = np.concatenate((existing_shape[1], polyline), axis=0)
                        elif min_dist_idx == 2:
                            combined_points = np.concatenate((polyline, existing_shape[1]), axis=0)
                        else:
                            combined_points = np.concatenate((polyline, existing_shape[1][::-1]), axis=0)
                        
                        if len(combined_points) > 2:
                            line_error, _, current_slope_intercept = fit_line(polyline)
                            if line_error < 5:
                                existing_slope = existing_shape[4][0][0]
                                current_slope = current_slope_intercept[0][0]
                                angle_radians = math.atan(abs((existing_slope - current_slope) /
                                                              (1 + existing_slope * current_slope)))
                                angle_degrees = math.degrees(angle_radians)
                                if angle_degrees >= 40:
                                    continue

                        _, best_fit_points, symmetry_data = fit_line(combined_points)
                        existing_shape[0].add(i)
                        completed_shapes[j] = [existing_shape[0], combined_points, best_fit_points, "line", symmetry_data]
                        matched = True
                        break

                elif calculate_polygon_error(polyline, existing_shape[2]) < 10:
                    start1, end1 = polyline[0], polyline[-1]
                    start2, end2 = existing_shape[1][0], existing_shape[1][-1]
                    if points_are_close(start1, start2):
                        combined_points = np.concatenate((polyline, existing_shape[1][::-1]), axis=0)
                    elif points_are_close(start1, end2):
                        combined_points = np.concatenate((polyline, existing_shape[1]), axis=0)
                    elif points_are_close(end1, start2):
                        combined_points = np.concatenate((existing_shape[1], polyline), axis=0)
                    elif points_are_close(end1, end2):
                        combined_points = np.concatenate((existing_shape[1][::-1], polyline), axis=0)
                    else:
                        combined_points = np.concatenate((existing_shape[1], polyline), axis=0)
                    best_fit_points, _, best_polygon, symmetry_data = fit_shape(combined_points)
                    existing_shape[0].add(i)
                    completed_shapes[j] = [existing_shape[0], combined_points, best_fit_points, best_polygon, symmetry_data]
                    matched = True
                    break
            if matched:
                continue
        
        best_fit_points, min_error, best_shape, symmetry_data = fit_shape(polyline)
        if min_error < 10:
            completed_shapes.append([{i}, polyline, best_fit_points, best_shape, symmetry_data])

    return completed_shapes

# Example usage
# path = 'path_to_data.csv'
# polylines = read_csv(path)

