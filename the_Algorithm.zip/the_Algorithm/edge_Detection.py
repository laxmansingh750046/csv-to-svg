import cv2
import pandas as pd
import numpy as np

# Edge detection functions

def canny_edge_detection(image_path, output_csv_path):
    img = cv2.imread(image_path)
    img = cv2.GaussianBlur(img, (5, 5), sigmaX=0, sigmaY=0) 
    edges = cv2.Canny(img, 50, 60)
    contours, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    data = []
    polyline_index = 0
    for contour in contours:
        polyline = contour[:, 0, :]
        for point in polyline:
            x, y = point
            data.append([polyline_index, 0, x, y])
        polyline_index += 1
    df = pd.DataFrame(data, columns=['polyline_index', 'unused_col', 'x', 'y'])
    df.to_csv(output_csv_path, index=False)

def sobel_edge_detection(image_path, output_csv_path):
    img = cv2.imread(image_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img = cv2.GaussianBlur(img, (3, 3), sigmaX=0, sigmaY=0) 
    sobel_x = cv2.Sobel(img, cv2.CV_64F, 1, 0, ksize=3)
    sobel_y = cv2.Sobel(img, cv2.CV_64F, 0, 1, ksize=3)
    magnitude = cv2.magnitude(sobel_x, sobel_y)
    magnitude = cv2.normalize(magnitude, None, 0, 255, cv2.NORM_MINMAX)
    magnitude = np.uint8(magnitude)
    _, binary_edges = cv2.threshold(magnitude, 50, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(binary_edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    data = []
    polyline_index = 0
    for contour in contours:
        polyline = contour[:, 0, :]
        for point in polyline:
            x, y = point
            data.append([polyline_index, 0, x, y])
        polyline_index += 1
    df = pd.DataFrame(data, columns=['polyline_index', 'unused_col', 'x', 'y'])
    df.to_csv(output_csv_path, index=False)

# Example usage
canny_edge_detection(r'misc-outputs\frag2.png', 'polylines.csv')
