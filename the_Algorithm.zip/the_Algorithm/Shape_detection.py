import numpy as np
from shapely.geometry import Polygon, Point, MultiPoint
from scipy.optimize import least_squares
from helper import read_csv, plot
import cv2
from scipy.interpolate import splev, splrep
import scipy
from sklearn.linear_model import LinearRegression
from find_reflection_symmetry_line import find_reflection_symmetry_parallel, find_centroid

def points_are_close(point1, point2, tolerance=1e-5):
    distance = np.linalg.norm(np.array(point1) - np.array(point2))
    return distance < tolerance

def calculate_polygon_error(original_points, fitted_points):
    fitted_polygon = Polygon(fitted_points).exterior
    distances = [fitted_polygon.distance(Point(p)) for p in original_points]
    return np.mean(distances)

def fit_shapes(polyline_group):
    fitted_shapes = []
    shape_names = []
    shape_errors = []
    shape_symmetries = []
    
    for polylines in polyline_group:
        for polyline in polylines:
            best_shape_points, lowest_error, best_shape, symmetry_lines = fit_shape(polyline)
            if lowest_error < 10:
                fitted_shapes.append(best_shape_points)
                shape_names.append(best_shape)
                shape_errors.append(lowest_error)
                shape_symmetries.append(symmetry_lines)
            else:
                bezier_error, bezier_points, symmetry_lines = fit_bezier_curve(polyline)
                if bezier_error < 10:
                    fitted_shapes.append(bezier_points)
                    shape_names.append("bezier")
                    shape_errors.append(bezier_error)
                    shape_symmetries.append(symmetry_lines)
                else:
                    spline_error, spline_points, symmetry_lines = fit_b_spline(polyline)
                    fitted_shapes.append(spline_points)
                    shape_names.append("b-spline")
                    shape_errors.append(spline_error)
                    shape_symmetries.append(symmetry_lines)
    
    return [fitted_shapes], shape_names, shape_symmetries

def fit_shape(points, simple_case=False):
    points = np.array(points)

    if np.all(points[0] == points[-1]) or points_are_close(points[0], points[-1]):
        centroid = find_centroid(points)
        symmetry_line, error = find_reflection_symmetry_parallel(points, centroid)
        if error < 1.1:
            return points, error, "closed", [symmetry_line]
    
    line_error, line_points, line_symmetry = fit_line(points)
    rectangle_error, rectangle_points, rectangle_symmetry = fit_rectangle(points)
    ellipse_error, ellipse_points, ellipse_symmetry = fit_ellipse(points)
    star_error, star_points, star_symmetry = fit_star(points)
    triangle_error, triangle_points, triangle_symmetry = fit_triangle(points, simple_case)
    pentagon_error, pentagon_points, pentagon_symmetry = fit_pentagon(points, simple_case)
    hexagon_error, hexagon_points, hexagon_symmetry = fit_hexagon(points, simple_case)
    
    all_errors = [
        ["line", line_error, line_points, line_symmetry],
        ["rectangle/square", rectangle_error, rectangle_points, rectangle_symmetry],
        ["ellipse/circle", ellipse_error, ellipse_points, ellipse_symmetry],
        ["star", star_error, star_points, star_symmetry],
        ["triangle", triangle_error, triangle_points, triangle_symmetry],
        ["pentagon", pentagon_error, pentagon_points, pentagon_symmetry],
        ["hexagon", hexagon_error, hexagon_points, hexagon_symmetry]
    ]
    all_errors = sorted(all_errors, key=lambda x: x[1])
    best_shape = all_errors[0][0]
    lowest_error = all_errors[0][1]
    best_shape_points = all_errors[0][2]
    symmetry_lines = all_errors[0][3]

    if abs(line_error - lowest_error) < 0.2:
        best_shape = "line"
        best_shape_points = line_points
        symmetry_lines = line_symmetry
        lowest_error = line_error

    print(f"Errors: line={line_error:.2f}, rectangle={rectangle_error:.9f}, ellipse={ellipse_error:.2f}, "
          f"star={star_error:.2f}, triangle={triangle_error:.2f}, "
          f"pentagon={pentagon_error:.2f}, hexagon={hexagon_error:.2f}")

    return best_shape_points, lowest_error, best_shape, symmetry_lines

def fit_line(points):
    x = points[:, 0]
    y = points[:, 1]
    
    # Fit y on x
    X_y_on_x = x.reshape(-1, 1)
    model_y_on_x = LinearRegression().fit(X_y_on_x, y)
    slope_y_on_x = model_y_on_x.coef_[0]
    intercept_y_on_x = model_y_on_x.intercept_
    line_y_on_x = slope_y_on_x * x + intercept_y_on_x
    line_points_y_on_x = np.column_stack((x, line_y_on_x))
    error_y_on_x = np.mean(np.abs(line_y_on_x - y))
    
    # Fit x on y
    X_x_on_y = y.reshape(-1, 1)
    model_x_on_y = LinearRegression().fit(X_x_on_y, x)
    slope_x_on_y = model_x_on_y.coef_[0]
    intercept_x_on_y = model_x_on_y.intercept_
    line_x_on_y = (x - intercept_x_on_y) / slope_x_on_y
    line_points_x_on_y = np.column_stack((line_x_on_y, y))
    error_x_on_y = np.mean(np.abs(line_x_on_y - x))
    
    # Choose the best fit
    if error_y_on_x < error_x_on_y:
        best_error = error_y_on_x
        best_line_points = line_points_y_on_x
        best_symmetry_lines = [(slope_y_on_x, intercept_y_on_x)]
    else:
        best_error = error_x_on_y
        best_line_points = line_points_x_on_y
        best_symmetry_lines = [(1 / slope_x_on_y, -intercept_x_on_y / slope_x_on_y)]
    
    return best_error, best_line_points, best_symmetry_lines

def fit_rectangle(points):
    if len(points) < 4:
        return float('inf'), points, []
    multi_point = MultiPoint(points)
    rect = multi_point.minimum_rotated_rectangle
    rect_points = np.array(rect.exterior.coords)
    
    rectangle_error = calculate_polygon_error(points, rect_points)

    symmetry_lines = []
    for i in range(2):
        p1 = rect_points[i]
        p2 = rect_points[(i + 1) % len(rect_points)]
        p3 = rect_points[(i + 2) % len(rect_points)]
        p4 = rect_points[(i + 3) % len(rect_points)]
        midpoint1 = [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2]
        midpoint2 = [(p3[0] + p4[0]) / 2, (p3[1] + p4[1]) / 2]
        if abs(midpoint1[0] - midpoint2[0]) < 1e-6:
            slope = np.inf
            intercept = midpoint1[0]
        else:
            slope = (midpoint2[1] - midpoint1[1]) / (midpoint2[0] - midpoint1[0])
            intercept = midpoint1[1] - slope * midpoint1[0]
        symmetry_lines.append((slope, intercept))

    return rectangle_error, rect_points, symmetry_lines

def fit_ellipse(points):
    if len(points) < 5:
        return float('inf'), points, []

    points = np.array(points, dtype=np.float32)
    ellipse = cv2.fitEllipse(points)
    center = ellipse[0]
    axes = ellipse[1]
    angle = ellipse[2]

    angle_rad = np.deg2rad(angle)

    a = axes[0] / 2
    b = axes[1] / 2

    num_points = 1000
    t = np.linspace(0, 2 * np.pi, num_points)
    ellipse_points = np.zeros((num_points, 2), dtype=np.float32)
    
    for i in range(num_points):
        x = a * np.cos(t[i])
        y = b * np.sin(t[i])
        
        x_rot = x * np.cos(angle_rad) - y * np.sin(angle_rad)
        y_rot = x * np.sin(angle_rad) + y * np.cos(angle_rad)
        
        ellipse_points[i] = [center[0] + x_rot, center[1] + y_rot]
    
    ellipse_points = np.array(ellipse_points, dtype=np.float32)
    
    ellipse_error = calculate_polygon_error(points, ellipse_points)
    
    multi_point = MultiPoint(ellipse_points)
    rect = multi_point.minimum_rotated_rectangle
    rect_points = np.array(rect.exterior.coords)

    symmetry_lines = []
    for i in range(2):
        p1 = rect_points[i]
        p2 = rect_points[(i + 1) % len(rect_points)]
        p3 = rect_points[(i + 2) % len(rect_points)]
        p4 = rect_points[(i + 3) % len(rect_points)]
        midpoint1 = [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2]
        midpoint2 = [(p3[0] + p4[0]) / 2, (p3[1] + p4[1]) / 2]
        if abs(midpoint1[0] - midpoint2[0]) < 1e-6:
            slope = np.inf
            intercept = midpoint1[0]
        else:
            slope = (midpoint2[1] - midpoint1[1]) / (midpoint2[0] - midpoint1[0])
            intercept = midpoint1[1] - slope * midpoint1[0]
        symmetry_lines.append((slope, intercept))

    return ellipse_error, ellipse_points, symmetry_lines

def fit_star(points):
    # Placeholder for star fitting algorithm
    return float('inf'), points, []

def fit_triangle(points, simple_case=False):
    # Placeholder for triangle fitting algorithm
    return float('inf'), points, []

def fit_pentagon(points, simple_case=False):
    # Placeholder for pentagon fitting algorithm
    return float('inf'), points, []

def fit_hexagon(points, simple_case=False):
    # Placeholder for hexagon fitting algorithm
    return float('inf'), points, []

def fit_bezier_curve(points):
    points = np.array(points)
    t = np.linspace(0, 1, len(points))
    bezier_points = points
    bezier_curve = lambda t: np.dot(
        np.array([[1, -3, 3, -1], [0, 3, -6, 3], [0, 0, 3, -3], [0, 0, 0, 1]]) / 6.0,
        np.array([1, t, t**2, t**3])[:, np.newaxis]
    ).flatten()

    bezier_error = np.mean(np.abs(np.array([bezier_curve(ti) for ti in t]) - points[:, 1]))
    return bezier_error, bezier_points, []

def fit_b_spline(points):
    points = np.array(points)
    tck, u = splrep(np.arange(len(points)), points[:, 1], s=0)
    spline_points = np.array([splev(ti, tck) for ti in np.linspace(0, len(points) - 1, len(points))])
    spline_error = np.mean(np.abs(spline_points - points[:, 1]))
    return spline_error, spline_points, []

def fit_polygon(points, num_sides):
    if num_sides < 3:
        return float('inf'), points, []

    multi_point = MultiPoint(points)
    polygon = multi_point.minimum_rotated_rectangle
    polygon_points = np.array(polygon.exterior.coords)
    if len(polygon_points) < num_sides:
        return float('inf'), points, []

    polygon_error = calculate_polygon_error(points, polygon_points)
    symmetry_lines = []
    for i in range(num_sides):
        p1 = polygon_points[i]
        p2 = polygon_points[(i + 1) % len(polygon_points)]
        midpoint1 = [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2]
        if abs(midpoint1[0] - midpoint1[1]) < 1e-6:
            slope = np.inf
            intercept = midpoint1[0]
        else:
            slope = (p2[1] - p1[1]) / (p2[0] - p1[0])
            intercept = midpoint1[1] - slope * midpoint1[0]
        symmetry_lines.append((slope, intercept))

    return polygon_error, polygon_points, symmetry_lines
