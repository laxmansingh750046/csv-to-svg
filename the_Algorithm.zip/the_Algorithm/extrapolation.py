import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import distance
from scipy.interpolate import interp1d
from helper import read_csv

def extrapolate_missing_segments(polyline):
    t_values = np.linspace(0, 1, len(polyline))
    interpolation_function = interp1d(t_values, polyline, kind='quadratic', axis=0, fill_value="extrapolate")
    extended_t_values = np.linspace(0, 1.05, 600)
    distance_threshold = 1
    extrapolated_points = []
    extrapolation_started = False
    completion_status = False

    for t in extended_t_values:
        extrapolated_point = interpolation_function(t)
        minimum_distance = np.min([distance.euclidean(extrapolated_point, pt) for pt in polyline])
        extrapolated_points.append(extrapolated_point)
        if minimum_distance > distance_threshold:
            extrapolation_started = True
        
        if extrapolation_started and minimum_distance < distance_threshold:
            completion_status = True
            break 
    
    return np.array(extrapolated_points), completion_status
